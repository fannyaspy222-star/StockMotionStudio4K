package com.stockmotion.studio

import androidx.activity.ComponentActivity
import android.os.Bundle
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var preview: MotionPreview
    private var selectedName = "Belum ada aset dipilih"

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            selectedName = uri.lastPathSegment ?: "Aset terpilih"
            status.text = "Aset dipilih: $selectedName"
            preview.setAsset(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            setBackgroundColor(Color.rgb(246,247,251))
        }
        val brand = ImageView(this).apply {
            setImageResource(com.stockmotion.studio.R.drawable.stockmotion_brand)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = "StockMotion Studio 4K logo"
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, 150))
        root.addView(TextView(this).apply {
            text = "Stock video motion studio"; textSize = 14f
            setTextColor(Color.rgb(25,31,48)); typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Studio motion graphic untuk workflow microstock"
            textSize = 13f; setTextColor(Color.DKGRAY)
        })
        status = TextView(this).apply {
            text = "Pilih aset gambar. Pada prototipe ini preview raster PNG/JPG; dukungan parsing SVG sedang disiapkan."
            textSize = 13f; setPadding(0,14,0,10); setTextColor(Color.DKGRAY)
        }
        root.addView(status)
        preview = MotionPreview(this)
        root.addView(preview, LinearLayout.LayoutParams(-1, 220).apply { topMargin=8; bottomMargin=12 })

        section(root, "1. SVG to Motion", "Impor aset dan lihat pratinjau gerak dasar.")
        button(root, "Pilih SVG / PNG") { picker.launch(arrayOf("image/svg+xml","image/png","image/*")) }
        button(root, "Putar / jeda pratinjau") { preview.toggle() }

        section(root, "2. AI Text-to-Motion", "Pilih satu aset sebagai objek, lalu tulis gerakan dalam Bahasa Indonesia atau Inggris.")
        val promptInput = EditText(this).apply {
            hint = "Contoh: buat bola jatuh, memantul tiga kali, lalu berhenti / Make the ball bounce three times"
            minLines = 2
            maxLines = 4
            textSize = 14f
            setPadding(12, 10, 12, 10)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(promptInput, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        button(root, "Generate Motion") {
            val prompt = promptInput.text.toString()
            val result = preview.applyPrompt(prompt)
            status.text = result
        }
        button(root, "Reset gerakan") {
            preview.applyPrompt("rotate")
            status.text = "Gerakan direset ke pratinjau dasar."
        }

        section(root, "3. Seamless Loop", "Pratinjau gerakan berulang. Validasi loop final akan ditambahkan.")
        button(root, "Aktifkan / nonaktifkan loop") {
            preview.loop = !preview.loop
            status.text = if (preview.loop) "Loop pratinjau aktif" else "Loop pratinjau nonaktif"
        }

        section(root, "4. Background Generator", "Latar gradasi dengan beberapa preset.")
        button(root, "Ganti background") { preview.nextBackground() }

        section(root, "5. Export & Metadata", "Target pengembangan berikutnya: ekspor MP4 2K dan 4K. Encoder belum tersedia pada MVP ini.")
        button(root, "Buat draft metadata") {
            status.text = "Draft title: $selectedName • Keywords: motion, abstract, animation, background, design"
        }
        button(root, "Status ekspor & batch") {
            status.text = "MVP 0.2: logo dan prototipe Text-to-Motion aktif. Encoder MP4 2K/4K dan batch render belum tersedia."
        }
        section(root, "6. Export Resolution", "Pilihan target resolusi untuk tahap pengembangan renderer berikutnya.")
        val resolutionPicker = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("2K QHD • 2560 × 1440", "4K UHD • 3840 × 2160"))
        }
        root.addView(resolutionPicker, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 6 })
        button(root, "Simpan pilihan resolusi") {
            status.text = "Target ekspor dipilih: ${resolutionPicker.selectedItem}. Fitur render MP4 akan diimplementasikan pada tahap berikutnya."
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun section(root: LinearLayout, title: String, desc: String) {
        root.addView(TextView(this).apply {
            text=title; textSize=16f; typeface=Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(35,43,65)); setPadding(0,12,0,2)
        })
        root.addView(TextView(this).apply { text=desc; textSize=12f; setTextColor(Color.DKGRAY) })
    }
    private fun button(root: LinearLayout, label: String, action: () -> Unit) {
        root.addView(Button(this).apply { text=label; isAllCaps=false; setOnClickListener { action() } },
            LinearLayout.LayoutParams(-1,-2).apply { topMargin=5 })
    }
}

class MotionPreview(context: android.content.Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var start = System.currentTimeMillis()
    private var running = true
    var loop = true
    private var bg = 0
    private var bitmap: Bitmap? = null
    private var phase = 0f
    private var motionMode = "rotate"

    fun applyPrompt(prompt: String): String {
        val p = prompt.trim().lowercase()
        if (p.isEmpty()) return "Tulis instruksi gerakan terlebih dahulu."
        motionMode = when {
            listOf("bounce", "bouncing", "memantul", "pantul").any { p.contains(it) } -> "bounce"
            listOf("fall", "jatuh", "drop", "turun").any { p.contains(it) } -> "fall"
            listOf("float", "melayang", "mengambang", "terapung").any { p.contains(it) } -> "float"
            listOf("swing", "ayun", "berayun").any { p.contains(it) } -> "swing"
            listOf("shake", "goyang", "gemetar").any { p.contains(it) } -> "shake"
            listOf("fade", "menghilang", "transparan", "muncul perlahan").any { p.contains(it) } -> "fade"
            listOf("upward", "ke atas", "naik", "move up").any { p.contains(it) } -> "up"
            listOf("downward", "ke bawah", "move down").any { p.contains(it) } -> "down"
            listOf("rotate", "rotasi", "putar", "berputar").any { p.contains(it) } -> "rotate"
            else -> return "Instruksi belum dikenali. Coba: rotate, bounce, fall, float, swing, shake, fade, naik, atau turun."
        }
        start = System.currentTimeMillis()
        phase = 0f
        running = true
        invalidate()
        val label = when (motionMode) {
            "bounce" -> "Pantulan"; "fall" -> "Jatuh"; "float" -> "Melayang"; "swing" -> "Ayunan"
            "shake" -> "Goyang"; "fade" -> "Fade"; "up" -> "Gerak ke atas"; "down" -> "Gerak ke bawah"
            else -> "Rotasi"
        }
        return "Motion dibuat: $label. Ini prototipe interpreter dasar; satu aset yang dipilih diperlakukan sebagai satu objek."
    }

    fun toggle() { running=!running; if (running) start=System.currentTimeMillis()-(phase*3000).toLong(); invalidate() }
    fun nextBackground() { bg=(bg+1)%4; invalidate() }
    fun setAsset(uri: Uri) {
        try { val stream=context.contentResolver.openInputStream(uri); bitmap=BitmapFactory.decodeStream(stream); stream?.close() }
        catch (_: Exception) { bitmap=null }
        invalidate()
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val pairs = arrayOf(
            intArrayOf(Color.rgb(19,30,65),Color.rgb(50,91,150)),
            intArrayOf(Color.rgb(35,35,45),Color.rgb(115,65,140)),
            intArrayOf(Color.rgb(15,75,80),Color.rgb(65,145,125)),
            intArrayOf(Color.rgb(80,45,25),Color.rgb(190,125,65))
        )
        val c=pairs[bg]
        canvas.drawRect(0f,0f,width.toFloat(),height.toFloat(),Paint().apply {
            shader=LinearGradient(0f,0f,width.toFloat(),height.toFloat(),c[0],c[1],Shader.TileMode.CLAMP)
        })
        if (running) {
            val elapsed=(System.currentTimeMillis()-start)/3000f
            phase=elapsed-kotlin.math.floor(elapsed)
            postInvalidateDelayed(33)
        }
        val wave = kotlin.math.sin(phase * Math.PI * 2).toFloat()
        var cx = width / 2f
        var cy = height / 2f
        var rotation = 0f
        var scale = 1f
        var alpha = 255
        when (motionMode) {
            "bounce" -> cy += kotlin.math.abs(wave) * height * .24f - height * .12f
            "fall", "down" -> cy += phase * height * .28f - height * .14f
            "up" -> cy -= phase * height * .28f - height * .14f
            "float" -> cy += wave * height * .12f
            "swing" -> rotation = wave * 28f
            "shake" -> cx += wave * width * .08f
            "fade" -> alpha = (100 + (127 * (1f + wave))).toInt().coerceIn(0,255)
            "rotate" -> rotation = phase * 360f
        }
        if (motionMode == "bounce") scale = 1f - kotlin.math.abs(wave) * .08f
        val b=bitmap
        canvas.save()
        canvas.rotate(rotation, cx, cy)
        canvas.scale(scale, scale, cx, cy)
        if (b!=null) {
            val size=(height*.42f).toInt().coerceAtLeast(1)
            val dst=RectF(cx-size/2f,cy-size/2f,cx+size/2f,cy+size/2f)
            canvas.drawBitmap(b,null,dst,Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { this.alpha = alpha })
        } else {
            paint.color=Color.WHITE; paint.alpha=alpha
            canvas.drawCircle(cx,cy,28f+8f*kotlin.math.sin(phase*6.28f),paint)
            paint.color=Color.rgb(100,210,255); paint.alpha=alpha
            canvas.drawCircle(cx+38f,cy-24f,9f,paint)
            paint.alpha=255
        }
        canvas.restore()
        paint.color=Color.WHITE; paint.textSize=12f
        canvas.drawText("PREVIEW • 3s motion loop",14f,height-14f,paint)
    }
}
