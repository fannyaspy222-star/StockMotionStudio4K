# StockMotion Studio 4K — MVP 0.1

Starter Android/Kotlin project for POCO F6 (8 GB RAM), offline-first.

## Included in this first prototype
- Four-module home screen.
- Local document picker for SVG/PNG files.
- Animated preview with moving/rotating imported PNG bitmap.
- Four background preview presets.
- Basic draft metadata text.
- GitHub Actions workflow that builds a debug APK.

## Not implemented yet (do not treat as available features)
- SVG rendering (the picker accepts SVG, but this prototype currently decodes raster PNG only).
- MP4/H.264 video encoder and export.
- True seamless-loop frame validation.
- Batch rendering queue.
- 4K rendering pipeline and device performance tuning.
- Adobe Stock technical/metadata validation.

This MVP is a build-and-device prototype, not the finished stock-video production app. The pending features will be implemented and tested in later versions.

## Build
Push the project to GitHub. Open Actions, run "Build StockMotion Studio 4K", then download the `StockMotion-Studio-4K-APK` artifact from a successful run.


## MVP 0.2 update
- Added StockMotion Studio 4K brand artwork in the app header.
- Added Android launcher icon resources (legacy and adaptive icon).
- Added a bilingual starter Text-to-Motion interpreter for basic motion keywords: rotate, bounce, fall, float, swing, shake, fade, move up, and move down.
- Added 2K/4K export-resolution selection UI as a preparation step.

## Important implementation status
This is still an early prototype. Text-to-Motion currently maps supported words to simple preview transformations; it is not a full natural-language AI system and does not yet generate editable multi-step keyframes. The selected imported raster image is treated as one object. SVG parsing/layer selection, MP4 rendering, actual 2K/4K export, batch rendering, and metadata CSV export remain future work. The current preview image decoder supports raster formats such as PNG/JPEG, not SVG.
