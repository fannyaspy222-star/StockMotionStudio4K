package com.stockmotion.studio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Environment
import android.os.Build
import android.content.ContentValues
import android.provider.MediaStore
import java.io.File
import java.nio.ByteBuffer

/** Experimental byte-buffer H.264 renderer. Encodes one RGB frame at a time to limit memory use. */
object Mp4Exporter {
    fun export(
        context: Context,
        width: Int,
        height: Int,
        fps: Int,
        durationSeconds: Int,
        onProgress: (Float) -> Unit,
        frameProvider: (Float) -> android.graphics.Bitmap
    ): String {
        require(width % 2 == 0 && height % 2 == 0) { "Resolusi harus genap." }
        val outDir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir
        if (!outDir.exists()) outDir.mkdirs()
        val output = File(outDir, "StockMotion_${System.currentTimeMillis()}.mp4")
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar)
            setInteger(MediaFormat.KEY_BIT_RATE, when {
                width >= 3840 -> 24_000_000
                width >= 2560 -> 12_000_000
                else -> 6_000_000
            })
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }
        var codec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        var track = -1
        try {
            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val info = MediaCodec.BufferInfo()
            val totalFrames = fps * durationSeconds
            var inputDone = false
            var outputDone = false
            var frameIndex = 0
            while (!outputDone) {
                if (!inputDone) {
                    val inputIndex = codec.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val input = codec.getInputBuffer(inputIndex) ?: error("Buffer input encoder tidak tersedia")
                        if (frameIndex < totalFrames) {
                            val time = frameIndex.toFloat() / fps
                            val bitmap = frameProvider(time)
                            try { rgbToNv12(bitmap, input) } finally { bitmap.recycle() }
                            val pts = frameIndex * 1_000_000L / fps
                            codec.queueInputBuffer(inputIndex, 0, width * height * 3 / 2, pts, 0)
                            frameIndex++
                            val progressStep = (totalFrames / 100).coerceAtLeast(1)
                            if (frameIndex % progressStep == 0 || frameIndex == totalFrames) {
                                onProgress(frameIndex.toFloat() / totalFrames)
                            }
                        } else {
                            codec.queueInputBuffer(inputIndex, 0, 0, frameIndex * 1_000_000L / fps, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        }
                    }
                }
                val outputIndex = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        track = muxer.addTrack(codec.outputFormat)
                        muxer.start(); muxerStarted = true
                    }
                    outputIndex >= 0 -> {
                        val encoded = codec.getOutputBuffer(outputIndex)
                        if (encoded != null && info.size > 0 && muxerStarted) {
                            encoded.position(info.offset); encoded.limit(info.offset + info.size)
                            muxer.writeSampleData(track, encoded, info)
                        }
                        outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        codec.releaseOutputBuffer(outputIndex, false)
                    }
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, output.name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/StockMotion")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                val uri = context.contentResolver.insert(collection, values) ?: error("Tidak bisa membuat file di galeri")
                try {
                    context.contentResolver.openOutputStream(uri)?.use { dest -> output.inputStream().use { src -> src.copyTo(dest) } }
                        ?: error("Tidak bisa menulis video ke galeri")
                    values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0)
                    context.contentResolver.update(uri, values, null, null)
                    output.delete()
                    return uri.toString()
                } catch (t: Throwable) {
                    context.contentResolver.delete(uri, null, null)
                    throw t
                }
            }
            return output.absolutePath
        } catch (t: Throwable) {
            output.delete()
            throw t
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { if (muxerStarted) muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
        }
    }

    private fun rgbToNv12(bitmap: android.graphics.Bitmap, out: ByteBuffer) {
        out.clear()
        val w = bitmap.width; val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        val frameSize = w * h
        var yIndex = 0
        var uvIndex = frameSize
        for (row in 0 until h) {
            for (col in 0 until w) {
                val c = pixels[row * w + col]
                val r = (c shr 16) and 0xff; val g = (c shr 8) and 0xff; val b = c and 0xff
                val y = ((66*r + 129*g + 25*b + 128) shr 8) + 16
                out.put(yIndex++, y.coerceIn(0,255).toByte())
                if (row % 2 == 0 && col % 2 == 0) {
                    val u = ((-38*r - 74*g + 112*b + 128) shr 8) + 128
                    val v = ((112*r - 94*g - 18*b + 128) shr 8) + 128
                    out.put(uvIndex++, u.coerceIn(0,255).toByte())
                    out.put(uvIndex++, v.coerceIn(0,255).toByte())
                }
            }
        }
        out.flip()
    }
}
