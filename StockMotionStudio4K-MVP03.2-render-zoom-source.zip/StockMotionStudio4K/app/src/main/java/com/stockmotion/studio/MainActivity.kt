package com.stockmotion.studio

import androidx.activity.ComponentActivity
import android.os.Bundle
import android.content.Intent
import android.graphics.*
import android.os.Environment
import android.view.ScaleGestureDetector
import android.widget.HorizontalScrollView
import android.net.Uri
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var preview: MotionPreview
    private var selectedName = "Belum ada aset dipilih"

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            selectedName = uri.lastPathSegment ?: "Aset terpilih"
            status.text = "Aset dipilih: $selectedName"
            preview.setAsset(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("stockmotion_editor", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            setBackgroundColor(Color.rgb(246,247,251))
        }
        val brand = ImageView(this).apply {
            setImageResource(com.stockmotion.studio.R.drawable.stockmotion_brand)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = "StockMotion Studio 4K logo"
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, 150))
        root.addView(TextView(this).apply {
            text = "Stock video motion studio"; textSize = 14f
            setTextColor(Color.rgb(25,31,48)); typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Studio motion graphic untuk workflow microstock"
            textSize = 13f; setTextColor(Color.DKGRAY)
        })
        status = TextView(this).apply {
            text = "Pilih aset gambar. Pada prototipe ini preview raster PNG/JPG; dukungan parsing SVG sedang disiapkan."
            textSize = 13f; setPadding(0,14,0,10); setTextColor(Color.DKGRAY)
        }
        root.addView(status)
        preview = MotionPreview(this)
        root.addView(preview, LinearLayout.LayoutParams(-1, 360).apply { topMargin=8; bottomMargin=8 })
        val zoomRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val zoomOut = Button(this).apply { text = "− Zoom"; isAllCaps = false; setOnClickListener { preview.zoomBy(0.8f) } }
        val zoomIn = Button(this).apply { text = "+ Zoom"; isAllCaps = false; setOnClickListener { preview.zoomBy(1.25f) } }
        val zoomReset = Button(this).apply { text = "Reset"; isAllCaps = false; setOnClickListener { preview.resetZoom() } }
        zoomRow.addView(zoomOut, LinearLayout.LayoutParams(0, -2, 1f)); zoomRow.addView(zoomIn, LinearLayout.LayoutParams(0, -2, 1f)); zoomRow.addView(zoomReset, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(zoomRow)
        val detectedList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(detectedList)

        section(root, "1. SVG to Motion", "Impor aset dan lihat pratinjau gerak dasar.")
        button(root, "Pilih SVG / PNG") { picker.launch(arrayOf("image/svg+xml","image/png","image/*")) }
        button(root, "Putar / jeda pratinjau") { preview.toggle() }
        button(root, "Deteksi objek pada foto JPG / PNG") {
            status.text = "Sedang mendeteksi objek di foto..."
            preview.detectObjects { message ->
                status.text = message
                detectedList.removeAllViews()
                preview.detectedLabels().forEachIndexed { index, label ->
                    val itemButton = Button(this).apply {
                        text = "Pilih ${index + 1}: $label"
                        isAllCaps = false
                        setOnClickListener { preview.selectObject(index); status.text = "Objek dipilih: $label. Perbesar preview bila perlu." }
                    }
                    detectedList.addView(itemButton, LinearLayout.LayoutParams(-1, -2))
                }
            }
        }

        section(root, "2. Object Selection", "Ketuk kotak objek yang terdeteksi pada preview untuk memilihnya. Tahap ini memilih area objek; pemisahan tepi objek/latar transparan masih perlu tahap segmentation.")
        button(root, "Hapus pilihan objek") { preview.clearSelection(); status.text = "Pilihan objek dihapus." }

        section(root, "3. AI Text-to-Motion", "Pilih satu aset sebagai objek, lalu tulis gerakan dalam Bahasa Indonesia atau Inggris.")
        val promptInput = EditText(this).apply {
            hint = "Contoh: buat bola jatuh, memantul tiga kali, lalu berhenti / Make the ball bounce three times"
            minLines = 2
            maxLines = 4
            textSize = 14f
            setPadding(12, 10, 12, 10)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(promptInput, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        button(root, "Generate Motion") {
            val prompt = promptInput.text.toString()
            val result = preview.applyPrompt(prompt)
            status.text = result
        }
        button(root, "Reset gerakan") {
            preview.applyPrompt("rotate")
            status.text = "Gerakan direset ke pratinjau dasar."
        }

        section(root, "4. Seamless Loop", "Pratinjau gerakan berulang. Validasi loop final akan ditambahkan.")
        button(root, "Aktifkan / nonaktifkan loop") {
            preview.loop = !preview.loop
            status.text = if (preview.loop) "Loop pratinjau aktif" else "Loop pratinjau nonaktif"
        }

        section(root, "5. Background Generator", "Latar gradasi dengan beberapa preset.")
        button(root, "Ganti background") { preview.nextBackground() }

        section(root, "6. Export & Metadata", "Render MP4 H.264 tersedia sebagai fitur eksperimental; uji dahulu pada 1080p sebelum mencoba 2K/4K.")
        button(root, "Render & simpan MP4") {
            val seconds = prefs.getInt("duration_seconds", 10)
            val fps = prefs.getInt("fps", 30)
            val size = when (prefs.getInt("resolution_index", 0)) { 1 -> Pair(2560,1440); 2 -> Pair(3840,2160); else -> Pair(1920,1080) }
            if (!preview.hasAsset()) { status.text = "Pilih foto JPG/PNG terlebih dahulu." }
            else {
                status.text = "Menyiapkan render MP4 ${size.first}×${size.second}, $fps FPS, $seconds detik..."
                Thread {
                    try {
                        val file = Mp4Exporter.export(
                            context = this,
                            width = size.first,
                            height = size.second,
                            fps = fps,
                            durationSeconds = seconds,
                            onProgress = { t -> runOnUiThread { status.text = "Rendering: ${(t*100).toInt()}%" } },
                            frameProvider = { time -> preview.renderFrame(size.first, size.second, time) }
                        )
                        runOnUiThread { status.text = "MP4 berhasil disimpan ke Movies/StockMotion. Lokasi: $file" }
                    } catch (e: Exception) {
                        runOnUiThread { status.text = "Render gagal: ${e.localizedMessage ?: e.javaClass.simpleName}" }
                    }
                }.start()
            }
        }
        button(root, "Buat draft metadata") {
            status.text = "Draft title: $selectedName • Keywords: motion, abstract, animation, background, design"
        }
        button(root, "Status ekspor & batch") {
            status.text = "MVP 0.3.2: render MP4 H.264 eksperimental ditambahkan. Pemisahan objek per piksel belum tersedia; gerakan render masih diterapkan ke seluruh foto."
        }
        section(root, "7. Pengaturan Video", "Atur durasi, frame rate, dan resolusi target. Pengaturan tersimpan di perangkat untuk sesi editor berikutnya.")

        val durationLabel = TextView(this).apply {
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(35,43,65))
            setPadding(0, 10, 0, 2)
        }
        root.addView(durationLabel)
        val durationSeek = SeekBar(this).apply {
            max = 57 // 3..60 seconds
            progress = (prefs.getInt("duration_seconds", 10) - 3).coerceIn(0, 57)
        }
        root.addView(durationSeek, LinearLayout.LayoutParams(-1, -2))
        val durationHint = TextView(this).apply {
            text = "Rentang durasi: 3–60 detik"
            textSize = 12f
            setTextColor(Color.DKGRAY)
        }
        root.addView(durationHint)

        val fpsLabel = TextView(this).apply {
            text = "Frame rate (FPS)"
            textSize = 13f
            setTextColor(Color.rgb(35,43,65))
            setPadding(0, 10, 0, 2)
        }
        root.addView(fpsLabel)
        val fpsPicker = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("24 FPS", "25 FPS", "30 FPS"))
            setSelection(when (prefs.getInt("fps", 30)) { 24 -> 0; 25 -> 1; else -> 2 })
        }
        root.addView(fpsPicker, LinearLayout.LayoutParams(-1, -2))

        val resolutionLabel = TextView(this).apply {
            text = "Resolusi target"
            textSize = 13f
            setTextColor(Color.rgb(35,43,65))
            setPadding(0, 10, 0, 2)
        }
        root.addView(resolutionLabel)
        val resolutionPicker = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("1080p Full HD • 1920 × 1080", "2K QHD • 2560 × 1440", "4K UHD • 3840 × 2160"))
            setSelection(prefs.getInt("resolution_index", 0).coerceIn(0, 2))
        }
        root.addView(resolutionPicker, LinearLayout.LayoutParams(-1, -2))

        fun selectedFps(): Int = when (fpsPicker.selectedItemPosition) { 0 -> 24; 1 -> 25; else -> 30 }
        fun updateDurationSummary(save: Boolean) {
            val seconds = durationSeek.progress + 3
            val fps = selectedFps()
            durationLabel.text = "Durasi video: $seconds detik"
            durationHint.text = "$seconds detik × $fps FPS = ${seconds * fps} frame"
            if (save) {
                prefs.edit()
                    .putInt("duration_seconds", seconds)
                    .putInt("fps", fps)
                    .putInt("resolution_index", resolutionPicker.selectedItemPosition)
                    .apply()
            }
        }
        durationSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { updateDurationSummary(fromUser) }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) { updateDurationSummary(true) }
        })
        fpsPicker.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { updateDurationSummary(true) }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        resolutionPicker.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { updateDurationSummary(true) }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        updateDurationSummary(false)
        button(root, "Simpan pengaturan video") {
            updateDurationSummary(true)
            status.text = "Pengaturan tersimpan: ${durationSeek.progress + 3} detik • ${selectedFps()} FPS • ${resolutionPicker.selectedItem}. Jumlah frame: ${(durationSeek.progress + 3) * selectedFps()}. Catatan: encoder MP4 belum tersedia, jadi pengaturan ini belum menghasilkan file video."
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun section(root: LinearLayout, title: String, desc: String) {
        root.addView(TextView(this).apply {
            text=title; textSize=16f; typeface=Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(35,43,65)); setPadding(0,12,0,2)
        })
        root.addView(TextView(this).apply { text=desc; textSize=12f; setTextColor(Color.DKGRAY) })
    }
    private fun button(root: LinearLayout, label: String, action: () -> Unit) {
        root.addView(Button(this).apply { text=label; isAllCaps=false; setOnClickListener { action() } },
            LinearLayout.LayoutParams(-1,-2).apply { topMargin=5 })
    }
}

class MotionPreview(context: android.content.Context) : View(context) {
    init { isClickable = true }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var start = System.currentTimeMillis()
    private var running = true
    var loop = true
    private var bg = 0
    private var bitmap: Bitmap? = null
    private var phase = 0f
    private var motionMode = "rotate"
    private data class DetectedItem(val bounds: RectF, val label: String)
    private val detectedItems = mutableListOf<DetectedItem>()
    private var selectedIndex = -1
    private var detectionBusy = false
    private var statusCallback: ((String) -> Unit)? = null
    private var zoom = 1f
    private var panX = 0f
    private var panY = 0f
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            zoom = (zoom * detector.scaleFactor).coerceIn(1f, 5f)
            invalidate(); return true
        }
    })

    fun hasAsset() = bitmap != null
    fun detectedLabels(): List<String> = detectedItems.map { it.label }
    fun selectObject(index: Int) { if (index in detectedItems.indices) { selectedIndex = index; invalidate() } }
    fun zoomBy(factor: Float) { zoom = (zoom * factor).coerceIn(1f, 5f); if (zoom == 1f) { panX=0f; panY=0f }; invalidate() }
    fun resetZoom() { zoom=1f; panX=0f; panY=0f; invalidate() }
    fun renderFrame(outWidth: Int, outHeight: Int, timeSeconds: Float): Bitmap {
        val output = Bitmap.createBitmap(outWidth, outHeight, Bitmap.Config.ARGB_8888)
        val c = Canvas(output)
        val phaseNow = ((timeSeconds / 3f) % 1f)
        drawScene(c, outWidth, outHeight, phaseNow, false)
        return output
    }

    fun detectObjects(callback: (String) -> Unit) {
        val imageBitmap = bitmap
        if (imageBitmap == null) { callback("Pilih foto JPG atau PNG terlebih dahulu."); return }
        if (detectionBusy) { callback("Deteksi objek masih berjalan..."); return }
        detectionBusy = true
        statusCallback = callback
        val options = ObjectDetectorOptions.Builder()
            .setDetectorMode(ObjectDetectorOptions.SINGLE_IMAGE_MODE)
            .enableMultipleObjects()
            .enableClassification()
            .build()
        val detector = ObjectDetection.getClient(options)
        try {
            detector.process(InputImage.fromBitmap(imageBitmap, 0))
                .addOnSuccessListener { objects ->
                    detectedItems.clear()
                    objects.forEach { obj ->
                        val label = obj.labels.firstOrNull()?.text ?: "Objek"
                        detectedItems.add(DetectedItem(RectF(obj.boundingBox), label))
                    }
                    selectedIndex = -1
                    detectionBusy = false
                    callback(if (detectedItems.isEmpty())
                        "Belum ada objek yang berhasil dikenali. Coba foto dengan objek yang jelas dan tidak terlalu kecil."
                    else "Ditemukan ${detectedItems.size} objek. Ketuk salah satu kotak pada foto untuk memilihnya. Catatan: kotak deteksi belum merupakan potongan objek transparan.")
                    invalidate()
                    detector.close()
                }
                .addOnFailureListener { e ->
                    detectionBusy = false
                    callback("Deteksi gagal: ${e.localizedMessage ?: "kesalahan model"}. Coba lagi.")
                    detector.close()
                }
        } catch (e: Exception) {
            detectionBusy = false
            callback("Tidak dapat memproses foto: ${e.localizedMessage ?: "kesalahan tidak diketahui"}")
            detector.close()
        }
    }

    fun clearSelection() { selectedIndex = -1; invalidate() }

    private fun imageRect(): RectF {
        val b = bitmap ?: return RectF()
        if (width <= 0 || height <= 0) return RectF()
        val scale = minOf(width.toFloat() / b.width, height.toFloat() / b.height)
        val w = b.width * scale; val h = b.height * scale
        val cx=width/2f + panX; val cy=height/2f + panY
        val zw=w*zoom; val zh=h*zoom
        return RectF(cx-zw/2f, cy-zh/2f, cx+zw/2f, cy+zh/2f)
    }

    private fun mappedBounds(bounds: RectF): RectF {
        val b = bitmap ?: return RectF()
        val dst = imageRect()
        val sx = dst.width() / b.width; val sy = dst.height() / b.height
        return RectF(dst.left + bounds.left*sx, dst.top + bounds.top*sy,
            dst.left + bounds.right*sx, dst.top + bounds.bottom*sy)
    }

    override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> { lastTouchX=event.x; lastTouchY=event.y; return true }
            android.view.MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount == 1 && zoom > 1f && !scaleDetector.isInProgress) {
                    panX += event.x-lastTouchX; panY += event.y-lastTouchY
                    lastTouchX=event.x; lastTouchY=event.y; invalidate()
                }
                return true
            }
            android.view.MotionEvent.ACTION_UP -> {
                for (i in detectedItems.indices.reversed()) {
                    val hit = mappedBounds(detectedItems[i].bounds).apply { inset(-24f, -24f) }
                    if (hit.contains(event.x, event.y)) {
                        selectedIndex=i
                        statusCallback?.invoke("Objek dipilih: ${detectedItems[i].label}. Area deteksi dipilih; segmentation belum tersedia.")
                        invalidate(); performClick(); return true
                    }
                }
                performClick(); return true
            }
        }
        return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }

    fun applyPrompt(prompt: String): String {
        val p = prompt.trim().lowercase()
        if (p.isEmpty()) return "Tulis instruksi gerakan terlebih dahulu."
        if (selectedIndex >= 0) return "Objek '${detectedItems[selectedIndex].label}' sudah dipilih. Animasi independen untuk potongan objek belum aktif karena tahap segmentation belum selesai. Text-to-Motion belum boleh menggerakkan seluruh foto seolah-olah hanya objek itu."
        motionMode = when {
            listOf("bounce", "bouncing", "memantul", "pantul").any { p.contains(it) } -> "bounce"
            listOf("fall", "jatuh", "drop", "turun").any { p.contains(it) } -> "fall"
            listOf("float", "melayang", "mengambang", "terapung").any { p.contains(it) } -> "float"
            listOf("swing", "ayun", "berayun").any { p.contains(it) } -> "swing"
            listOf("shake", "goyang", "gemetar").any { p.contains(it) } -> "shake"
            listOf("fade", "menghilang", "transparan", "muncul perlahan").any { p.contains(it) } -> "fade"
            listOf("upward", "ke atas", "naik", "move up").any { p.contains(it) } -> "up"
            listOf("downward", "ke bawah", "move down").any { p.contains(it) } -> "down"
            listOf("rotate", "rotasi", "putar", "berputar").any { p.contains(it) } -> "rotate"
            else -> return "Instruksi belum dikenali. Coba: rotate, bounce, fall, float, swing, shake, fade, naik, atau turun."
        }
        start = System.currentTimeMillis(); phase = 0f; running = true; invalidate()
        return "Motion pratinjau dasar dibuat untuk seluruh gambar. Ini belum animasi objek independen."
    }

    fun toggle() { running=!running; if (running) start=System.currentTimeMillis()-(phase*3000).toLong(); invalidate() }
    fun nextBackground() { bg=(bg+1)%4; invalidate() }
    fun setAsset(uri: Uri) {
        try { val stream=context.contentResolver.openInputStream(uri); bitmap=BitmapFactory.decodeStream(stream); stream?.close(); detectedItems.clear(); selectedIndex=-1 }
        catch (_: Exception) { bitmap=null }
        invalidate()
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (running) { val elapsed=(System.currentTimeMillis()-start)/3000f; phase=elapsed-kotlin.math.floor(elapsed); postInvalidateDelayed(33) }
        drawScene(canvas, width, height, phase, true)
    }

    private fun drawScene(canvas: Canvas, drawWidth: Int, drawHeight: Int, phaseValue: Float, showLabels: Boolean) {
        val pairs = arrayOf(
            intArrayOf(Color.rgb(19,30,65),Color.rgb(50,91,150)),
            intArrayOf(Color.rgb(35,35,45),Color.rgb(115,65,140)),
            intArrayOf(Color.rgb(15,75,80),Color.rgb(65,145,125)),
            intArrayOf(Color.rgb(80,45,25),Color.rgb(190,125,65))
        )
        val c=pairs[bg]
        canvas.drawRect(0f,0f,drawWidth.toFloat(),drawHeight.toFloat(),Paint().apply {
            shader=LinearGradient(0f,0f,drawWidth.toFloat(),drawHeight.toFloat(),c[0],c[1],Shader.TileMode.CLAMP)
        })
        val wave = kotlin.math.sin(phaseValue * Math.PI * 2).toFloat()
        var cx = drawWidth / 2f; var cy = drawHeight / 2f; var rotation = 0f; var scale = 1f; var alpha = 255
        when (motionMode) {
            "bounce" -> cy += kotlin.math.abs(wave) * drawHeight * .24f - drawHeight * .12f
            "fall", "down" -> cy += phaseValue * drawHeight * .28f - drawHeight * .14f
            "up" -> cy -= phaseValue * drawHeight * .28f - drawHeight * .14f
            "float" -> cy += wave * drawHeight * .12f
            "swing" -> rotation = wave * 28f
            "shake" -> cx += wave * drawWidth * .08f
            "fade" -> alpha = (100 + (127 * (1f + wave))).toInt().coerceIn(0,255)
            "rotate" -> rotation = phaseValue * 360f
        }
        if (motionMode == "bounce") scale = 1f - kotlin.math.abs(wave) * .08f
        val b=bitmap
        if (b!=null) {
            val dst = if (drawWidth == width && drawHeight == height) imageRect() else {
                val scale=minOf(drawWidth.toFloat()/b.width, drawHeight.toFloat()/b.height)
                val w=b.width*scale; val h=b.height*scale
                RectF((drawWidth-w)/2f,(drawHeight-h)/2f,(drawWidth+w)/2f,(drawHeight+h)/2f)
            }
            canvas.save(); canvas.rotate(rotation,cx,cy); canvas.scale(scale,scale,cx,cy)
            canvas.drawBitmap(b,null,dst,Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { this.alpha=alpha })
            canvas.restore()
            if (showLabels) detectedItems.forEachIndexed { index, item ->
                val r=mappedBounds(item.bounds)
                val chosen=index==selectedIndex
                val p=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=if(chosen) Color.YELLOW else Color.CYAN; style=Paint.Style.STROKE; strokeWidth=if(chosen) 5f else 3f }
                canvas.drawRoundRect(r,8f,8f,p)
                if (chosen) {
                    p.style=Paint.Style.FILL; p.textSize=14f; p.typeface=Typeface.DEFAULT_BOLD
                    canvas.drawText(item.label,r.left.coerceAtLeast(4f),(r.top-7f).coerceAtLeast(16f),p)
                }
            }
        } else {
            paint.color=Color.WHITE; paint.alpha=alpha; canvas.drawCircle(cx,cy,28f+8f*kotlin.math.sin(phaseValue*6.28f),paint)
            paint.color=Color.rgb(100,210,255); paint.alpha=alpha; canvas.drawCircle(cx+38f,cy-24f,9f,paint); paint.alpha=255
        }
        paint.color=Color.WHITE; paint.textSize=12f; if (showLabels) canvas.drawText("PREVIEW • OBJECT DETECTION",14f,drawHeight-14f,paint)
    }
}
