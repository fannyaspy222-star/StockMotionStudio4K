# StockMotion Studio 4K — MVP 0.3

Android/Kotlin prototype for creating short motion-graphic stock clips.

## MVP 0.3 changes
- Larger preview workspace.
- Explicit Run Animation and Pause Animation controls.
- Apply Motion Prompt action for supported Indonesian/English keywords.
- Background preset and loop controls.
- MP4/H.264 export pipeline using Android MediaCodec surface input and MediaMuxer.
- 2K QHD (2560x1440) and 4K UHD (3840x2160) output choices, 24/30 FPS.
- Saves completed exports to `Movies/StockMotion` through MediaStore.

## Current limitations
- This is an early renderer prototype. Device codec support, memory use, render speed and visual output must be tested on real devices. 4K may fail or run slowly on some devices; test 2K first.
- SVG files are accepted by the picker but SVG parsing/rasterization and layer/object selection are not implemented. Use PNG/JPG for preview and rendering.
- The prompt interpreter is keyword/rule based, not a cloud AI model and not a full multi-step keyframe editor.
- The current MP4 renderer creates a 4-second clip from the selected asset, motion mode and background. It does not yet export audio, batch jobs, or Adobe Stock validation/metadata CSV.
- Seamless loop is currently a preview toggle; mathematical first/last frame loop validation is not implemented.

## Build
Push the project to GitHub. Run the `Build StockMotion Studio 4K` workflow and download the `StockMotion-Studio-4K-APK` artifact from a successful Actions run.
