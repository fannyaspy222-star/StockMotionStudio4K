package com.stockmotion.studio

import android.app.*
import android.content.ContentValues
import android.content.Intent
import android.graphics.*
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Surface
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.*

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var preview: MotionPreview
    private lateinit var renderButton: Button
    private val executor = Executors.newSingleThreadExecutor()
    private var selectedName = "Belum ada aset dipilih"
    private var selectedIsSvg = false
    private var selectedWidth = 2560
    private var selectedHeight = 1440

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            selectedName = uri.lastPathSegment ?: "Aset terpilih"
            selectedIsSvg = contentResolver.getType(uri)?.contains("svg", ignoreCase = true) == true || selectedName.lowercase().endsWith(".svg")
            status.text = "Aset dipilih: $selectedName"
            preview.setAsset(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 22)
            setBackgroundColor(Color.rgb(246,247,251))
        }
        val brand = ImageView(this).apply {
            setImageResource(R.drawable.stockmotion_brand)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = "StockMotion Studio 4K logo"
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, 126))
        root.addView(TextView(this).apply {
            text = "Stock video motion studio"; textSize = 14f
            setTextColor(Color.rgb(25,31,48)); typeface = Typeface.DEFAULT_BOLD
        })
        status = TextView(this).apply {
            text = "Pilih aset, atur gerakan, jalankan animasi, lalu render menjadi MP4."
            textSize = 13f; setPadding(0,10,0,8); setTextColor(Color.DKGRAY)
        }
        root.addView(status)

        section(root, "PREVIEW STUDIO", "Area pratinjau diperbesar. Tekan Jalankan Animasi setelah memilih gerakan.")
        preview = MotionPreview(this)
        root.addView(preview, LinearLayout.LayoutParams(-1, dp(340)).apply { topMargin=8; bottomMargin=8 })
        button(root, "Pilih SVG / PNG / JPG") { picker.launch(arrayOf("image/svg+xml","image/png","image/jpeg","image/*")) }
        button(root, "▶ Jalankan Animasi") {
            preview.play()
            status.text = "Animasi dijalankan. Lihat hasilnya di area preview."
        }
        button(root, "Ⅱ Jeda Animasi") {
            preview.pause()
            status.text = "Preview dijeda. Tekan Jalankan Animasi untuk melanjutkan."
        }

        section(root, "1. AI TEXT-TO-MOTION", "Masukkan instruksi sederhana dalam Bahasa Indonesia atau Inggris.")
        val promptInput = EditText(this).apply {
            hint = "Contoh: bola jatuh lalu memantul / make it bounce"
            minLines = 2; maxLines = 4; textSize = 14f; setPadding(12,10,12,10); setBackgroundColor(Color.WHITE)
        }
        root.addView(promptInput, LinearLayout.LayoutParams(-1,-2).apply { topMargin=8 })
        button(root, "Terapkan Gerakan") {
            val result = preview.applyPrompt(promptInput.text.toString())
            status.text = result
        }
        button(root, "Reset Gerakan") { preview.applyPrompt("rotate"); status.text = "Gerakan direset ke rotasi." }

        section(root, "2. SEAMLESS LOOP", "Atur apakah animasi berulang selama preview.")
        button(root, "Aktifkan / Nonaktifkan Loop") {
            preview.loop = !preview.loop
            status.text = if (preview.loop) "Loop preview aktif." else "Loop preview nonaktif."
        }
        section(root, "3. BACKGROUND GENERATOR", "Ganti latar pratinjau dan hasil render.")
        button(root, "Ganti Background") { preview.nextBackground(); status.text = "Background diganti." }

        section(root, "4. EXPORT VIDEO", "Render animasi menjadi MP4 H.264 dan simpan ke folder Movies/StockMotion.")
        val resolutionPicker = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("2K QHD • 2560 × 1440", "4K UHD • 3840 × 2160"))
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (position == 0) { selectedWidth=2560; selectedHeight=1440 }
                    else { selectedWidth=3840; selectedHeight=2160 }
                }
            }
        }
        root.addView(resolutionPicker, LinearLayout.LayoutParams(-1,-2).apply { topMargin=8 })
        val fpsPicker = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("24 FPS", "30 FPS"))
        }
        root.addView(fpsPicker, LinearLayout.LayoutParams(-1,-2).apply { topMargin=6 })
        renderButton = Button(this).apply {
            text = "🎬 RENDER VIDEO MP4"; isAllCaps=false
            setOnClickListener {
                if (isSelectedAssetSvg()) {
                    status.text = "File SVG belum dapat dirasterisasi pada versi ini. Silakan pilih PNG atau JPG terlebih dahulu."
                    return@setOnClickListener
                }
                isEnabled = false
                text = "Sedang menyiapkan render…"
                val w=selectedWidth; val h=selectedHeight; val fps=if (fpsPicker.selectedItemPosition==0) 24 else 30
                status.text = "Rendering ${w}×${h} • $fps FPS. Jangan tutup aplikasi selama proses."
                val snapshot = preview.snapshotBitmap()
                val mode = preview.currentMotion()
                val bg = preview.currentBackground()
                executor.execute {
                    try {
                        val uri = Mp4Renderer(this@MainActivity).render(snapshot, w, h, fps, mode, bg) { message ->
                            runOnUiThread { status.text = message }
                        }
                        runOnUiThread {
                            status.text = "Render selesai! Video tersimpan di Movies/StockMotion."
                            Toast.makeText(this@MainActivity, "Video MP4 berhasil disimpan", Toast.LENGTH_LONG).show()
                            isEnabled = true; text = "🎬 RENDER VIDEO MP4"
                            if (uri != null) {
                                val open = Button(this@MainActivity).apply { text="Buka Video Hasil Render"; isAllCaps=false; setOnClickListener {
                                    val intent=Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri,"video/mp4"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                                    try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this@MainActivity,"Video tersimpan di Movies/StockMotion",Toast.LENGTH_LONG).show() }
                                } }
                                (root.getChildAt(root.childCount-1) as? Button)?.let { /* keep layout stable */ }
                                root.addView(open, LinearLayout.LayoutParams(-1,-2).apply { topMargin=6 })
                            }
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            status.text = "Render gagal: ${e.message ?: "codec tidak mendukung konfigurasi ini"}. Coba 2K atau 24 FPS."
                            isEnabled = true; text = "🎬 RENDER VIDEO MP4"
                        }
                    } finally { snapshot?.recycle() }
                }
            }
        }
        root.addView(renderButton, LinearLayout.LayoutParams(-1,-2).apply { topMargin=10 })
        button(root, "Buat Draft Metadata") {
            status.text = "Draft title: $selectedName • Keywords: motion, animation, abstract, background, design"
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun isSelectedAssetSvg(): Boolean = selectedIsSvg
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun section(root: LinearLayout, title: String, desc: String) {
        root.addView(TextView(this).apply { text=title; textSize=15f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(35,43,65)); setPadding(0,13,0,2) })
        root.addView(TextView(this).apply { text=desc; textSize=12f; setTextColor(Color.DKGRAY) })
    }
    private fun button(root: LinearLayout, label: String, action: () -> Unit) {
        root.addView(Button(this).apply { text=label; isAllCaps=false; setOnClickListener { action() } }, LinearLayout.LayoutParams(-1,-2).apply { topMargin=5 })
    }
    override fun onDestroy() { super.onDestroy(); executor.shutdown() }
}

class MotionPreview(context: android.content.Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var start = System.currentTimeMillis()
    private var running = true
    var loop = true
    private var bg = 0
    private var bitmap: Bitmap? = null
    private var phase = 0f
    private var motionMode = "rotate"

    fun currentMotion() = motionMode
    fun currentBackground() = bg
    fun snapshotBitmap(): Bitmap? = bitmap?.let { Bitmap.createBitmap(it.width, it.height, Bitmap.Config.ARGB_8888).also { out -> Canvas(out).drawBitmap(it,0f,0f,null) } }
    fun play() { running=true; start=System.currentTimeMillis()-(phase*3000).toLong(); invalidate() }
    fun pause() { running=false; invalidate() }
    fun toggle() { if (running) pause() else play() }
    fun nextBackground() { bg=(bg+1)%4; invalidate() }
    fun setAsset(uri: Uri) {
        try { val stream=context.contentResolver.openInputStream(uri); bitmap=BitmapFactory.decodeStream(stream); stream?.close() }
        catch (_: Exception) { bitmap=null }
        invalidate()
    }
    fun applyPrompt(prompt: String): String {
        val p=prompt.trim().lowercase(Locale.ROOT)
        if (p.isEmpty()) return "Tulis instruksi gerakan terlebih dahulu."
        motionMode=when {
            listOf("bounce","bouncing","memantul","pantul").any { p.contains(it) } -> "bounce"
            listOf("fall","jatuh","drop","turun").any { p.contains(it) } -> "fall"
            listOf("float","melayang","mengambang","terapung").any { p.contains(it) } -> "float"
            listOf("swing","ayun","berayun").any { p.contains(it) } -> "swing"
            listOf("shake","goyang","gemetar").any { p.contains(it) } -> "shake"
            listOf("fade","menghilang","transparan","muncul perlahan").any { p.contains(it) } -> "fade"
            listOf("upward","ke atas","naik","move up").any { p.contains(it) } -> "up"
            listOf("downward","ke bawah","move down").any { p.contains(it) } -> "down"
            listOf("rotate","rotasi","putar","berputar").any { p.contains(it) } -> "rotate"
            else -> return "Instruksi belum dikenali. Coba rotate, bounce, fall, float, swing, shake, fade, naik, atau turun."
        }
        phase=0f; start=System.currentTimeMillis(); running=true; invalidate()
        return "Gerakan diterapkan: ${motionMode.uppercase(Locale.ROOT)}. Tekan Jalankan Animasi untuk memutar preview."
    }

    override fun onDraw(canvas: Canvas) { super.onDraw(canvas); val p=if(running) ((System.currentTimeMillis()-start)/3000f)%1f else phase; if(running) { phase=p; postInvalidateDelayed(33) }; drawFrame(canvas,width,height,p,motionMode,bg,bitmap) }

    companion object {
        fun drawFrame(canvas: Canvas, width: Int, height: Int, progress: Float, mode: String, bg: Int, bitmap: Bitmap?) {
            val pairs=arrayOf(intArrayOf(Color.rgb(19,30,65),Color.rgb(50,91,150)),intArrayOf(Color.rgb(35,35,45),Color.rgb(115,65,140)),intArrayOf(Color.rgb(15,75,80),Color.rgb(65,145,125)),intArrayOf(Color.rgb(80,45,25),Color.rgb(190,125,65)))
            val colors=pairs[bg%pairs.size]
            canvas.drawRect(0f,0f,width.toFloat(),height.toFloat(),Paint().apply { shader=LinearGradient(0f,0f,width.toFloat(),height.toFloat(),colors[0],colors[1],Shader.TileMode.CLAMP) })
            val wave=sin(progress*PI*2).toFloat(); var cx=width/2f; var cy=height/2f; var rotation=0f; var scale=1f; var alpha=255
            when(mode) {
                "bounce" -> cy += abs(wave)*height*.24f-height*.12f
                "fall","down" -> cy += progress*height*.28f-height*.14f
                "up" -> cy -= progress*height*.28f-height*.14f
                "float" -> cy += wave*height*.12f
                "swing" -> rotation=wave*28f
                "shake" -> cx += wave*width*.08f
                "fade" -> alpha=(100+127*(1f+wave)).toInt().coerceIn(0,255)
                "rotate" -> rotation=progress*360f
            }
            if(mode=="bounce") scale=1f-abs(wave)*.08f
            canvas.save(); canvas.rotate(rotation,cx,cy); canvas.scale(scale,scale,cx,cy)
            if(bitmap!=null) {
                val size=min(width,height)*.58f; val ratio=bitmap.width.toFloat()/bitmap.height.toFloat(); val dw=if(ratio>=1) size else size*ratio; val dh=if(ratio>=1) size/ratio else size
                canvas.drawBitmap(bitmap,null,RectF(cx-dw/2,cy-dh/2,cx+dw/2,cy+dh/2),Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { this.alpha=alpha })
            } else {
                val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.WHITE; this.alpha=alpha }
                canvas.drawCircle(cx,cy,min(width,height)*.12f+min(width,height)*.035f*sin(progress*6.28f),paint)
                paint.color=Color.rgb(100,210,255); canvas.drawCircle(cx+min(width,height)*.14f,cy-min(width,height)*.09f,min(width,height)*.035f,paint)
            }
            canvas.restore(); canvas.drawText("PREVIEW • ${mode.uppercase(Locale.ROOT)}",14f,height-16f,Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.WHITE; textSize=12f })
        }
    }
}

class Mp4Renderer(private val activity: ComponentActivity) {
    fun render(bitmap: Bitmap?, width: Int, height: Int, fps: Int, mode: String, background: Int, progress: (String)->Unit): Uri? {
        val date=SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(Date())
        val name="StockMotion_$date.mp4"
        val values=ContentValues().apply { put(MediaStore.Video.Media.DISPLAY_NAME,name); put(MediaStore.Video.Media.MIME_TYPE,"video/mp4"); if(Build.VERSION.SDK_INT>=29) put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/StockMotion") }
        val resolver=activity.contentResolver
        val uri=resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,values) ?: throw IllegalStateException("Tidak dapat membuat file video di galeri")
        var codec:MediaCodec?=null; var muxer:MediaMuxer?=null; var input:Surface?=null; var pfd:android.os.ParcelFileDescriptor?=null; var muxerStarted=false; var track=-1
        try {
            val format=MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC,width,height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT,MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE,if(width>=3840) 18000000 else 10000000)
                setInteger(MediaFormat.KEY_FRAME_RATE,fps); setInteger(MediaFormat.KEY_I_FRAME_INTERVAL,2)
            }
            codec=MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC); codec.configure(format,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE)
            input=codec.createInputSurface(); codec.start()
            pfd=resolver.openFileDescriptor(uri,"w") ?: throw IllegalStateException("Tidak bisa membuka file output")
            muxer=MediaMuxer(pfd!!.fileDescriptor,MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val info=MediaCodec.BufferInfo(); val total=fps*4; var frame=0; var eos=false
            while(frame<total) {
                val canvas=input.lockCanvas(null)
                try { MotionPreview.drawFrame(canvas,width,height,frame.toFloat()/total,mode,background,bitmap) }
                finally { input.unlockCanvasAndPost(canvas) }
                frame++
                if(frame%fps==0) progress("Rendering… ${frame/fps} dari 4 detik")
                var draining=true
                while(draining) {
                    val index=codec.dequeueOutputBuffer(info,10000)
                    when {
                        index==MediaCodec.INFO_TRY_AGAIN_LATER -> draining=false
                        index==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> { if(muxerStarted) throw IllegalStateException("Format encoder berubah"); track=muxer.addTrack(codec.outputFormat); muxer.start(); muxerStarted=true }
                        index>=0 -> {
                            val buffer=codec.getOutputBuffer(index)!!
                            if(info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG!=0) info.size=0
                            if(info.size>0) { if(!muxerStarted) throw IllegalStateException("Format video belum siap"); buffer.position(info.offset); buffer.limit(info.offset+info.size); muxer.writeSampleData(track,buffer,info) }
                            if(info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM!=0) eos=true
                            codec.releaseOutputBuffer(index,false); if(eos) draining=false
                        }
                    }
                }
            }
            codec.signalEndOfInputStream()
            while(!eos) {
                val index=codec.dequeueOutputBuffer(info,10000)
                when {
                    index==MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                    index==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> { if(!muxerStarted) { track=muxer.addTrack(codec.outputFormat); muxer.start(); muxerStarted=true } }
                    index>=0 -> {
                        val buffer=codec.getOutputBuffer(index)!!
                        if(info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG!=0) info.size=0
                        if(info.size>0 && muxerStarted) { buffer.position(info.offset); buffer.limit(info.offset+info.size); muxer.writeSampleData(track,buffer,info) }
                        eos=info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM!=0; codec.releaseOutputBuffer(index,false)
                    }
                }
            }
            if(muxerStarted) muxer.stop()
            if(Build.VERSION.SDK_INT>=29) { val done=ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING,0) }; resolver.update(uri,done,null,null) }
            progress("Video selesai disimpan ke Movies/StockMotion")
            return uri
        } catch(e:Exception) { resolver.delete(uri,null,null); throw e }
        finally { try { muxer?.release() } catch(_:Exception){}; try { pfd?.close() } catch(_:Exception){}; try { codec?.stop() } catch(_:Exception){}; try { codec?.release() } catch(_:Exception){}; try { input?.release() } catch(_:Exception){} }
    }
}
