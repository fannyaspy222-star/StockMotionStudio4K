package com.stockmotion.studio

import androidx.activity.ComponentActivity
import android.os.Bundle
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var preview: MotionPreview
    private var selectedName = "Belum ada aset dipilih"

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            selectedName = uri.lastPathSegment ?: "Aset terpilih"
            status.text = "Aset dipilih: $selectedName"
            preview.setAsset(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            setBackgroundColor(Color.rgb(246,247,251))
        }
        root.addView(TextView(this).apply {
            text = "StockMotion Studio 4K"; textSize = 24f
            setTextColor(Color.rgb(25,31,48)); typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Studio motion graphic untuk workflow microstock"
            textSize = 13f; setTextColor(Color.DKGRAY)
        })
        status = TextView(this).apply {
            text = "Pilih aset PNG untuk memulai pratinjau."
            textSize = 13f; setPadding(0,14,0,10); setTextColor(Color.DKGRAY)
        }
        root.addView(status)
        preview = MotionPreview(this)
        root.addView(preview, LinearLayout.LayoutParams(-1, 220).apply { topMargin=8; bottomMargin=12 })

        section(root, "1. SVG to Motion", "Impor aset dan lihat pratinjau gerak dasar.")
        button(root, "Pilih SVG / PNG") { picker.launch(arrayOf("image/svg+xml","image/png","image/*")) }
        button(root, "Putar / jeda pratinjau") { preview.toggle() }

        section(root, "2. Seamless Loop", "Pratinjau gerakan berulang. Validasi loop final akan ditambahkan.")
        button(root, "Aktifkan / nonaktifkan loop") {
            preview.loop = !preview.loop
            status.text = if (preview.loop) "Loop pratinjau aktif" else "Loop pratinjau nonaktif"
        }

        section(root, "3. Background Generator", "Latar gradasi dengan beberapa preset.")
        button(root, "Ganti background") { preview.nextBackground() }

        section(root, "4. Export & Metadata", "Rancangan ekspor MP4, batch render, dan metadata.")
        button(root, "Buat draft metadata") {
            status.text = "Draft title: $selectedName • Keywords: motion, abstract, animation, background, design"
        }
        button(root, "Status ekspor & batch") {
            status.text = "MVP 0.1: preview aktif. Encoder MP4, 4K, dan batch render belum tersedia."
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun section(root: LinearLayout, title: String, desc: String) {
        root.addView(TextView(this).apply {
            text=title; textSize=16f; typeface=Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(35,43,65)); setPadding(0,12,0,2)
        })
        root.addView(TextView(this).apply { text=desc; textSize=12f; setTextColor(Color.DKGRAY) })
    }
    private fun button(root: LinearLayout, label: String, action: () -> Unit) {
        root.addView(Button(this).apply { text=label; isAllCaps=false; setOnClickListener { action() } },
            LinearLayout.LayoutParams(-1,-2).apply { topMargin=5 })
    }
}

class MotionPreview(context: android.content.Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var start = System.currentTimeMillis()
    private var running = true
    var loop = true
    private var bg = 0
    private var bitmap: Bitmap? = null
    private var phase = 0f

    fun toggle() { running=!running; if (running) start=System.currentTimeMillis()-(phase*3000).toLong(); invalidate() }
    fun nextBackground() { bg=(bg+1)%4; invalidate() }
    fun setAsset(uri: Uri) {
        try { val stream=context.contentResolver.openInputStream(uri); bitmap=BitmapFactory.decodeStream(stream); stream?.close() }
        catch (_: Exception) { bitmap=null }
        invalidate()
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val pairs = arrayOf(
            intArrayOf(Color.rgb(19,30,65),Color.rgb(50,91,150)),
            intArrayOf(Color.rgb(35,35,45),Color.rgb(115,65,140)),
            intArrayOf(Color.rgb(15,75,80),Color.rgb(65,145,125)),
            intArrayOf(Color.rgb(80,45,25),Color.rgb(190,125,65))
        )
        val c=pairs[bg]
        canvas.drawRect(0f,0f,width.toFloat(),height.toFloat(),Paint().apply {
            shader=LinearGradient(0f,0f,width.toFloat(),height.toFloat(),c[0],c[1],Shader.TileMode.CLAMP)
        })
        if (running) {
            val elapsed=(System.currentTimeMillis()-start)/3000f
            phase=elapsed-kotlin.math.floor(elapsed)
            postInvalidateDelayed(33)
        }
        val cx=width/2f+kotlin.math.sin(phase*Math.PI*2).toFloat()*width*.22f
        val cy=height/2f
        val b=bitmap
        if (b!=null) {
            val size=(height*.42f).toInt().coerceAtLeast(1)
            val dst=RectF(cx-size/2f,cy-size/2f,cx+size/2f,cy+size/2f)
            canvas.save(); canvas.rotate(phase*360f,cx,cy)
            canvas.drawBitmap(b,null,dst,Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)); canvas.restore()
        } else {
            paint.color=Color.WHITE; canvas.drawCircle(cx,cy,28f+8f*kotlin.math.sin(phase*6.28f),paint)
            paint.color=Color.rgb(100,210,255); canvas.drawCircle(cx+38f,cy-24f,9f,paint)
        }
        paint.color=Color.WHITE; paint.textSize=12f
        canvas.drawText("PREVIEW • 3s motion loop",14f,height-14f,paint)
    }
}
