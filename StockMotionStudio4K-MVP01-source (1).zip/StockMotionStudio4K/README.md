# StockMotion Studio 4K — MVP 0.1

Starter Android/Kotlin project for POCO F6 (8 GB RAM), offline-first.

## Included in this first prototype
- Four-module home screen.
- Local document picker for SVG/PNG files.
- Animated preview with moving/rotating imported PNG bitmap.
- Four background preview presets.
- Basic draft metadata text.
- GitHub Actions workflow that builds a debug APK.

## Not implemented yet (do not treat as available features)
- SVG rendering (the picker accepts SVG, but this prototype currently decodes raster PNG only).
- MP4/H.264 video encoder and export.
- True seamless-loop frame validation.
- Batch rendering queue.
- 4K rendering pipeline and device performance tuning.
- Adobe Stock technical/metadata validation.

This MVP is a build-and-device prototype, not the finished stock-video production app. The pending features will be implemented and tested in later versions.

## Build
Push the project to GitHub. Open Actions, run "Build StockMotion Studio 4K", then download the `StockMotion-Studio-4K-APK` artifact from a successful run.
